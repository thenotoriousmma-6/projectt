package com.cg.iqgexception;

public class IQGException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IQGException(String message) {
		
		super(message);
	}

}
