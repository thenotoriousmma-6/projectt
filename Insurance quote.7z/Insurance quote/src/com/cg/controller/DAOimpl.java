package com.cg.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.model.Login;

public class DAOimpl {
	Connection connection = null;
	String driverName = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String username = "KONDEPATISAICHARIT";
	String password = "Cenation7.";

	public Connection getConnection() {
		try {
			Class.forName(driverName);
			// creating connection to database
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("connection established");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	public String  valid(Login login){
		
		ResultSet rs= null;
		PreparedStatement st=null;
		String role =null;
		connection = getConnection();
		try {						
			st = connection.prepareStatement("select * from user_role where user_name=? and password=?");	
			st.setString(1, login.getUserName());
			st.setString(2,login.getPassword());
			rs = st.executeQuery();
			while (rs.next()) {		
				String dummyu =  rs.getString(1);
				String dummyp = rs.getString(2);
				if(dummyu.equals(login.getUserName()) && dummyp.equals(login.getPassword())){
					role = rs.getString(3);
					break;		
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return role;
	}
}
